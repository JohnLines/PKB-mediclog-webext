

document.body.style.border = "4px solid green";
// would like to set this to the value from preferences.
