# PKB-mediclog-webext
Web extension to assist data entry into the Patients Know Best website

The Patients Know Best web site lacks an API to simplify data entry for normal users of the site. This web extension attempts to work around that shortcoming.

